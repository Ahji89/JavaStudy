package homework.SeHee_Kim;

public class CheckCard extends AccountBank{
	String cardNum;
	
	CheckCard(String accountNum, String accountHolder,String cardNum) {
		super(accountNum, accountHolder);
		this.cardNum = cardNum;
	}
	
	// üũī�����
	public void pay(int amount) {
		if(super.withdraw(amount) == true){
			int point = (int)(amount*0.1);
			balance += point;
			System.out.println("����Ʈ���� : " + point);
		}
	}
}
