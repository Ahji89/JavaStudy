package homework.SeHee_Kim;

public interface Account {
	void deposit(int amount);
	boolean withdraw(int amount);
}
