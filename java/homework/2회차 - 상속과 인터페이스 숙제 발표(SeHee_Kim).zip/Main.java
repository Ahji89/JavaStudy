package homework.SeHee_Kim;

public class Main {
	public static void main(String[] args) {
		AccountBank accountBank = new AccountBank("1111","�輼��");
		CheckCard checkCard = new CheckCard(accountBank.accountNum,accountBank.accountHolder,"1111_1");
		accountBank.deposit(3000);
		checkCard.deposit(100000);
		accountBank.deposit(4000);
		checkCard.deposit(100000);
		checkCard.pay(100);
		
		CreditCard creditCard = new CreditCard("2222","�輼��","2222_1",100000);
		creditCard.payWithCreditCard(100);
		creditCard.withdraw(100);
		
		accountBank.deposit(10);
	}
}
