package homework.SeHee_Kim;

public class AccountBank implements Account{
	String accountNum;
	String accountHolder;
	Integer balance = 0;
	
	AccountBank(String accountNum, String accountHolder){
		this.accountNum = accountNum;
		this.accountHolder = accountHolder;
	}
	
	public void deposit(int amount) {
		this.balance += amount;
		System.out.println(amount+"���� �ԱݵǾ����ϴ�. �ܾ� : " + balance);
	}

	public boolean withdraw(int amount) {
		if(this.balance >= amount){
			this.balance -= amount;
			System.out.println(amount+"���� ����Ǿ����ϴ�. �ܾ� : " + balance);
			return true;
		}
		else{
			System.out.println("�ܾ׺���");
			return false;
		}
	}
	
}
