package homework.YongJae_Hong;

interface Account {
	void deposit(int money);
	void withdraw(int money);
}
class BankAccount implements Account{
	//�������
		String AccountNumber;
		String Name;
		static double balance;
		void Account(String AccountNumber, String Name,int money)
		{
			this.AccountNumber = AccountNumber;
			this.Name = Name;
			BankAccount.balance += money;
		}
		public void deposit(int money){
			BankAccount.balance += money;
			System.out.println("�ܾ��� : " + BankAccount.balance);

		} //����
		public void withdraw(int money){
			if(BankAccount.balance < money)
			{
				System.out.println("�ܾ��� �����մϴ�.");
				System.out.println("���� �ܾ��� : " + BankAccount.balance);
			}
			else {
			
			
			BankAccount.balance = balance - money;
			System.out.println("�ܾ��� : " + BankAccount.balance);

			}
		} //���

		public BankAccount(String AccountNumber, String Name, double balance) {
			this.AccountNumber = AccountNumber;
			this.Name = Name;
			BankAccount.balance += balance;
			// TODO Auto-generated constructor stub
		}
}

class creditAccount extends BankAccount{
	public creditAccount(String AccountNumber, String Name, double money, String cardNumber) {
			super(AccountNumber, Name, balance);
			this.cardNumber = cardNumber;
			// TODO Auto-generated constructor stub
		}
		//�ſ�ī�� 
		String cardNumber;
		double point;

		public void payment(int money){
			BankAccount.balance = BankAccount.balance - money;
			point = 0.01 * (double)money;
			BankAccount.balance += point;
			System.out.println("��� �ݾ��� 1%�� ����Ʈ�� �����˴ϴ�. " + point);
			System.out.println("�ܾ��� : " + BankAccount.balance);
			
		}

		public void deposit(int money) {
			BankAccount.balance += money;
			// TODO Auto-generated method stub
			System.out.println("�ܾ��� : " + BankAccount.balance);
	
		}
	}

	class checkingAccount extends BankAccount{
		checkingAccount(String AccountNumber, String Name, int money,String cardNumber) {
			super(AccountNumber, Name, money);
			// TODO Auto-generated constructor stub
		}

		String cardNumber;
		double point;

		public void deposit(int money){
			BankAccount.balance += money;
			System.out.println("�ܾ��� : " + BankAccount.balance);
		}

		public void payment(int money){
			if(BankAccount.balance < money)
			{
				System.out.println("�ܾ��� �����մϴ�.");
				System.out.println("���� �ܾ��� : " + BankAccount.balance);
			}
			
			BankAccount.balance = balance - money + 0.01*(double)money;
			System.out.println("�ܾ��� : " + BankAccount.balance);

			
		} 
	}