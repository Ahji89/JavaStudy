package homework.ChangSoo_Yu;

public class Test {

	public static void main(String[] args) {
		IAccount checking = new CheckingAccount(1111, "checking", 10000, 1111);
		IAccount credit = new CreditAccount(2222, "credit", 10000, 2222);

		checking.deposit(10000);
		System.out.println(checking);

		checking.withdraw(30000);

		if (checking instanceof CheckingAccount) {
			((CheckingAccount) checking).cardPay(10000);
			System.out.println(checking);
		}

		System.out.println();

		credit.withdraw(20000);

		if (credit instanceof CreditAccount) {
			((CreditAccount) credit).cardPay(20000);
			System.out.println(credit);
		}
		
		// ���� �� �� (credit�� CheckingAccount�� ������ instance�� �ƴϱ� ������)
		if (credit instanceof CheckingAccount) {
			((CreditAccount) credit).cardPay(20000);
			System.out.println(credit);
		}
	}

}
