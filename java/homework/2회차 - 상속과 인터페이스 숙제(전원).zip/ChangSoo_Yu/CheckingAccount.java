package homework.ChangSoo_Yu;

public class CheckingAccount extends BankAccount {
	public static final double interest = 0.01;
	private int cardNo;

	public int getCardNo() {
		return cardNo;
	}

	public void setCardNo(int cardNo) {
		this.cardNo = cardNo;
	}

	public CheckingAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CheckingAccount(int accountNo, String name, double balance, int cardNo) {
		super(accountNo, name, balance);
		this.cardNo = cardNo;
	}

	public void cardPay(int amount) {
		if (getBalance() < amount) {
			System.out.println("not enough balance");
		} else {
			setBalance(getBalance() - amount + (double) (amount * interest));
		}
	}

	@Override
	public String toString() {
		return "CheckingAccount [accountNo=" + this.getAccountNo() + ", name=" + this.getName() + ", balance="
				+ this.getBalance() + ", cardNo=" + this.getCardNo() + "]";
	}

}
