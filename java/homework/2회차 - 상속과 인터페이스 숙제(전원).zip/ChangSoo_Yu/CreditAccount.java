package homework.ChangSoo_Yu;

public class CreditAccount extends BankAccount {
	public static final double interest = 0.01;
	private int cardNo;

	public int getCardNo() {
		return cardNo;
	}

	public void setCardNo(int cardNo) {
		this.cardNo = cardNo;
	}

	public CreditAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CreditAccount(int accountNo, String name, double balance, int cardNo) {
		super(accountNo, name, balance);
		this.cardNo = cardNo;
	}

	public void cardPay(int amount) {
		setBalance(getBalance() - amount + (double) (amount * interest));
	}

	@Override
	public String toString() {
		return "CreditAccount [accountNo=" + this.getAccountNo() + ", name=" + this.getName() + 
				", balance=" + this.getBalance() +", cardNo=" + this.getCardNo() + "]";
	}

	
}
