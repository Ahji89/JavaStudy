package homework.TaeWan_Kwon;

public class CheckCardAccount extends BankAccount {
	
	String cardNo;

	public CheckCardAccount(String accountNumber, String owner, int balance,String cardNo) {
		super(accountNumber, owner, balance);
		this.cardNo = cardNo;
	}

	

}

	


	
	


