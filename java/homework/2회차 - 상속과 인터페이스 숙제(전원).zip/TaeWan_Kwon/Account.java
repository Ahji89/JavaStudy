package homework.TaeWan_Kwon;

public interface Account {
	
	public void deposit();
	public void withdraw();		
}
