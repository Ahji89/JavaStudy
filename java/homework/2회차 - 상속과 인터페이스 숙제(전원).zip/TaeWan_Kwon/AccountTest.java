package homework.TaeWan_Kwon;

import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class AccountTest {
	
	private static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		BankAccount account = new BankAccount();
		
		boolean run = true;		
		while(run) {
			/*System.out.println("----------------------------------------------------------");
			System.out.println("1.���»��� | 2.���¸�� | 3.���� | 4.��� | 5.����");
			System.out.println("----------------------------------------------------------");
			System.out.print("����> "); */
			
			/*int selectNo = scanner.nextInt();*/
			try{
			int selectNo = Integer.parseInt(JOptionPane.showInputDialog("1.���»��� | 2.���¸�� | 3.���� | 4.��� | 5.����"));
			
			if(selectNo == 1) {
				account.createAccount();
			} else if(selectNo == 2) {
				account.accountList();
			} else if(selectNo == 3) {
				account.deposit();
			} else if(selectNo == 4) {
				account.withdraw();
			} else if(selectNo == 5) {
				run = false;
			}
			}catch(Exception e){
				continue;
			}
		}
		System.out.println("���α׷� ����");
	}

	}


