package homework.TaeWan_Kwon;

public class CreditAccount extends BankAccount {

	String cardNumber;
	
	public CreditAccount(String accountNumber, String owner, int balance,String cardNumber) {
		super(accountNumber, owner, balance);
		this.cardNumber = cardNumber;
	}

	public void payment(int money,String cardNumber){
		if(this.cardNumber.equals(cardNumber)){
			super.balance -= money;
			if(super.balance < 0){
				
			}
		}
	}
	
	
	
	
	
}
