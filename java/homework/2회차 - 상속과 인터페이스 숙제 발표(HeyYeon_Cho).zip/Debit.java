package homework.HyeYeon_Cho;

public class Debit extends Account {
	final String debitNumber = "3246-7916-4500-8319";
	
	public int useDebit(int won) {
		// TODO Auto-generated method stub
		System.out.println("[����ī�� ����]");
		
		int tmp_bal = balance;
		
		super.draw(won);
		
		if(won <= tmp_bal){
			balance = (int) (won * point) + balance;
			print("debit", (int)(won * point));
			System.out.println();
		}
		
		return balance;
	}
}

class DebitMain{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Debit debit = new Debit();
		debit.deposit(20000);
		debit.useDebit(10000);
		debit.draw(10000);
		debit.useDebit(10000);
		debit.deposit(20000);
		debit.useDebit(15522);
		debit.useDebit(999999);
		debit.useDebit(10000);
	}
}
