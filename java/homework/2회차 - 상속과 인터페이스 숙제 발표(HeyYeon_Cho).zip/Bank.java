package homework.HyeYeon_Cho;

interface Bank{
	int deposit(int won);
	int draw(int won);
}
