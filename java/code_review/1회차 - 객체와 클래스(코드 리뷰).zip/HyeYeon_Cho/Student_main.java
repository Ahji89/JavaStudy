package code_review.HyeYeon_Cho;

import code_review.HyeYeon_Cho.Student;

public class Student_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student gilDong_Hong = new Student("ȫ�浿", 79, 85, 66);
		Student hyeongSu_Kim = new Student("������", 88, 96, 100);
		Student naRa_Kim = new Student("�質��", 93, 87, 74);
		
		gilDong_Hong.print();
		hyeongSu_Kim.print();
		naRa_Kim.print();
	}

}
