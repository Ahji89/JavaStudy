package src;

class Box{ 
       public void simpleWrap(){System.out.println("simple wrap");} 
   } 
   
   class PaperBox extends Box{ 
       public void paperWrap(){System.out.println("paper wrap");} 
   } 
   
   class GoldPaperBox extends PaperBox{ 
      public void goldWrap(){System.out.println("gold wrap");} 
  } 
  
  class InstanceOf { 
       
      public static void main(String[] args) { 
      // TODO Auto-generated method stub 
           
      Box box1=new Box(); 
      PaperBox box2=new PaperBox(); 
      GoldPaperBox box3=new GoldPaperBox(); 
  
      System.out.println(box1 instanceof PaperBox); 
      System.out.println(box1 instanceof GoldPaperBox); 
      System.out.println(box2 instanceof Box); 
      System.out.println(box2 instanceof GoldPaperBox); 
      System.out.println(box3 instanceof Box); 
      System.out.println(box3 instanceof PaperBox); 
           
      } 
  }

