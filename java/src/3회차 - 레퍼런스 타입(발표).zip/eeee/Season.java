package src.eeee;

enum Season {
    SPRING, SUMMER, FALL, WINTER
}


