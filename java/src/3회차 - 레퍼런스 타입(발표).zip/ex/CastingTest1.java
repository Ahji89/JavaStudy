package src.ex;

class CastingTest1 { 
      public static void main(String args[]) { 
            Car car = new Car(); 
            if(car instanceof FireEngine){
            FireEngine fireEngine = (FireEngine)car;
            }else{
            	System.out.println("ĳ������ �Ҽ� �����ϴ�.");
            }
 
           
      } 
} 

class Car { 
      String color; 
      int door; 
      void drive() {             
            System.out.println("drive, Brrrr~"); 
      } 
      void stop() {                    
            System.out.println("stop!!!");       
      } 
} 

class FireEngine extends Car {       
      void water() {                   
            System.out.println("water!!!"); 
      } 
} 














