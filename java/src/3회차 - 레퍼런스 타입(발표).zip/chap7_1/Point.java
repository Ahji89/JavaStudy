package src.chap7_1;

class Point {
	int x, y;   
	Point(int x, int y) {           
	    this.x = x;
	    this.y = y;
	}
}
	
	



